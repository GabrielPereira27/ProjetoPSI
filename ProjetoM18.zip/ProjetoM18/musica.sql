
CREATE TABLE albuns (
    id_album int(11) AUTO_INCREMENT NOT NULL,
    titulo varchar(50) Not NULL,
    id_genero int(11) not null,
    id_musico int(11) DEFAULT NULL,
    data_lancamento date DEFAULT NULL,  
    observacoes varchar(255) NULL,
    updated_at timestamp NULL DEFAULT NULL,
    created_at timestamp NULL DEFAULT NULL,
    primary KEY (id_album)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE musicas (
    id_musica int(11) NOT NULL AUTO_INCREMENT,
    titulo varchar(50) Not NULL,
    id_musico int(11) DEFAULT NULL,
    id_album int(11) DEFAULT NULL,
    id_genero int(11) not null,
    updated_at timestamp NULL DEFAULT NULL,
    created_at timestamp NULL DEFAULT NULL,
    PRIMARY KEY (id_musica)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE musicos (
    id_musico  int(11) AUTO_INCREMENT NOT NULL,
    nome varchar(50) Not NULL,
    nacionalidade varchar(20)  NULL,
    data_nascimento datetime  NULL,
    fotografia varchar(255) NULL,
    updated_at timestamp NULL DEFAULT NULL,
    created_at timestamp NULL DEFAULT NULL,
    primary key (id_musico)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE generos (
  id_genero int(11) AUTO_INCREMENT  NOT NULL,
  designacao varchar(30) NOT NULL,
  observacoes varchar(255) NULL,  
  created_at timestamp NULL DEFAULT NULL,
  updated_at timestamp NULL DEFAULT NULL,
  PRIMARY KEY (id_genero)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
